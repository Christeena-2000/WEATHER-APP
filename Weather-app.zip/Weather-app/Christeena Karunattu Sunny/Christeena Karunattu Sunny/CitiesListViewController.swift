//
//  CitiesListViewController.swift
//
//  Created by Christeena Karunattu Sunny on 13/12/2023.
//

import UIKit

class CitiesListViewController: UIViewController , UITableViewDelegate , UITableViewDataSource {
  
    

    @IBOutlet weak var tableView: UITableView!
    var citiesList = [Weather]()
    var currentTempType = 0
   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
  
    @IBAction func actionBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.citiesList.count
    }
    

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CitiesTableViewCell", for: indexPath) as! CitiesTableViewCell
        cell.selectionStyle = .none
        
        cell.configureView(weather: self.citiesList[indexPath.row] ,type: self.currentTempType)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
}
