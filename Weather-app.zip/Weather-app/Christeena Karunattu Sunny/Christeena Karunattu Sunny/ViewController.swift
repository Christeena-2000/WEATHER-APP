//
//  ViewController.swift
//
//  Created by Christeena Karunattu Sunny on 12/12/2023.
//

import UIKit
import CoreLocation

class ViewController: UIViewController , UISearchBarDelegate{
    
   
    
    @IBOutlet weak var lblLocationName: UILabel!
    @IBOutlet weak var lblTemp: UILabel!
    @IBOutlet weak var iconType: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var locationManager: CLLocationManager = CLLocationManager()
    var currentTempType = 0 //0 for C and 1 for F
    var lastWeather : Weather?
    var citiesList  = [Weather]()
    let nightIcon: [Int : String ] = [1000 : "moon.fill", 1003 : "cloud.moon.fill", 1006 : "cloud.fill" , 1009 : "cloud.fill", 1030 : "cloud.fog.fill",1063 : "cloud.moon.rain", 1066 :"moon.snow",1069 : "cloud.sleet.fill", 1072 : "cloud.drizzle.fill"  , 1087 : "cloud.moon.bolt",1114 : "wind.snow", 1117 : "cloud.snow.fil", 1135 : "cloud.fog.fill", 1147 : "cloud.sleet.fill", 1150 : "cloud.drizzle.fill",1153 : "cloud.drizzle.fill", 1168 : "cloud.snow.fill", 1171 : "cloud.rain.fill", 1180 : "cloud.rain.fill", 1183 : "cloud.rain.fill",1186 : "cloud.moon.rain.fill", 1189 : "cloud.rain.fill", 1192 : "cloud.moon.rain.fill" , 1195 : "cloud.heavyrain.fill"  ,1198 : "cloud.sleet.fill",1201 : "cloud.sleet.fill", 1204 : "cloud.snow.fill", 1207 : "cloud.sleet.fill", 1210 : "moon.dust.fill", 1213 : "cloud.snow.fill",1216 : "moon.dust.fill", 1219 : "cloud.snow.fill", 1222 : "cloud.snow.fill", 1225 : "cloud.snow", 1237 : "cloud.sleet.fill",1240 :"cloud.drizzle.fill", 1243 : "cloud.heavyrain.fill" , 1246 : "cloud.rain.fill", 1249 : "cloud.drizzle.fill", 1252 : "cloud.heavyrain.fill",1255 : "cloud.snow.fill", 1258 : "cloud.snow.fill", 1261 :"cloud.sleet.fill", 1264 : "cloud.sleet.fill", 1273 : "cloud.hail.fill",1276 : "cloud.bolt.rain.fill", 1279 : "cloud.sleet.fill", 1282 : "cloud.snow.fill"]

    let dayIcon: [ Int : String ] = [1000 : "sun.max", 1003 : "cloud.sun.fill", 1006 : "cloud.fill", 1009 : "cloud.fill", 1030 : "cloud.fog",1063 : "cloud.sun.rain", 1066 : "sun.snow", 1069 : "cloud.sleet"      , 1072 : "cloud.drizzle", 1087 : "cloud.sun.bolt",1114 : "wind.snow", 1117 : "cloud.snow"       , 1135 : "cloud.fog", 1147 : "cloud.sleet", 1150 : "cloud.drizzle",1153 : "cloud.drizzle", 1168 : "cloud.snow", 1171 : "cloud.rain", 1180 : "cloud.rain.fill", 1183 : "cloud.rain.fill",1186 : "cloud.sun.rain", 1189 : "cloud.rain", 1192 : "cloud.sun.rain", 1195 : "cloud.heavyrain", 1198 : "cloud.sleet",1201 : "cloud.sleet", 1204 : "cloud.snow", 1207 : "cloud.sleet", 1210 : "sun.snow", 1213 : "cloud.snow",1216 : "sun.snow", 1219 : "cloud.snow", 1222 : "cloud.snow", 1225 : "cloud.snow", 1237 : "cloud.sleet",1240 : "cloud.drizzle", 1243 : "cloud.heavyrain"  , 1246 : "cloud.rain", 1249 : "cloud.drizzle", 1252 : "cloud.heavyrain",1255 : "cloud.snow", 1258 : "cloud.snow", 1261 : "cloud.sleet", 1264 : "cloud.sleet", 1273 : "cloud.hail",1276 : "cloud.bolt.rain", 1279 : "cloud.sleet", 1282 : "cloud.snow"]
   
    override func viewDidLoad() {
        super.viewDidLoad()
        self.iconType.tintColor = .white
        self.searchBar.delegate = self
        self.locationManager = CLLocationManager()
        self.locationManager.delegate = self
        self.locationManager.requestWhenInUseAuthorization()
        self.locationManager.startUpdatingLocation()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func actionCurrentLocation(_ sender: Any) {
        self.locationManager.startUpdatingLocation()
        self.locationManager.requestWhenInUseAuthorization()
    }
    
    @IBAction func actionTempType(_ sender: UISegmentedControl) {
        self.currentTempType = sender.selectedSegmentIndex
        if let lastWeather = self.lastWeather{
            self.updateViews(weatherDetails: lastWeather)
        }
    }
    
    @IBAction func actionCities(_ sender: Any) {
        if self.citiesList.count > 0{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "CitiesListViewController") as! CitiesListViewController
            vc.citiesList = self.citiesList
            vc.currentTempType = self.segmentedControl.selectedSegmentIndex
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if searchBar.text != ""{
            self.getWeatherDetails(query: searchBar.text ?? "") { weatherDetails in
                self.citiesList.append(weatherDetails)
                self.updateViews(weatherDetails: weatherDetails)
            }
        }
    }
    
    func getWeatherDetails(query : String , completion: @escaping (Weather)-> ()){
        let urlString = "https://api.weatherapi.com/v1/current.json?q=\(query)&key=55df498da0c2463b8fa160102231911"
        guard let encodedUrl = urlString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {return}
      
        if let url = URL(string: encodedUrl) {
            URLSession.shared.dataTask(with: url) {data, res, err in
                if err == nil{
                    if let data = data {
                        let decoder = JSONDecoder()
                        do {
                            let json: Weather = try! decoder.decode(Weather.self, from: data)
                            DispatchQueue.main.async {
                            if json.location?.name ?? "" != ""{
                                self.lastWeather = json
                               
                                    completion(json)
                                }
                            }
                        }catch let error {
                            print(error.localizedDescription)
                        }
                    }
                }
            }.resume()
        }
    }
}

extension ViewController : CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        self.locationManager.stopUpdatingLocation()
        if let location = locations.last {
            self.getWeatherDetails(query: "\(location.coordinate.latitude),\(location.coordinate.longitude)") { weatherDetails in
                self.citiesList.append(weatherDetails)
                self.updateViews(weatherDetails: weatherDetails)
            }
        }
    }
    
    func updateViews(weatherDetails : Weather){
        self.lblName.text = weatherDetails.current?.condition?.text ?? ""
        if currentTempType == 0{
            self.lblTemp.text = "\(weatherDetails.current?.tempC ?? 0)°"
        }
        else{
            self.lblTemp.text = "\(weatherDetails.current?.tempF ?? 0)°F"
        }
        self.lblLocationName.text = weatherDetails.location?.name ?? ""
        if (weatherDetails.current?.isDay ?? 0 != 0){
            self.iconType.image = UIImage(systemName: "\(dayIcon[weatherDetails.current?.condition?.code ?? 0] ?? "")")
        }
        else{
            self.iconType.image = UIImage(systemName: "\(nightIcon[weatherDetails.current?.condition?.code ?? 0] ?? "")")
        }
    }
}

