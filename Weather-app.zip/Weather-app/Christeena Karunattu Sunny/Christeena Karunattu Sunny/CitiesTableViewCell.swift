//
//  CitiesTableViewCell.swift
//
//  Created by Christeena Karunattu Sunny on 13/12/2023.
//

import UIKit

class CitiesTableViewCell: UITableViewCell {

    @IBOutlet weak var imgIcon: UIImageView!
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var lblTemp: UILabel!
    @IBOutlet weak var lblName: UILabel!
    
    let nightIcon: [Int : String ] = [1000 : "moon.fill", 1003 : "cloud.moon.fill", 1006 : "cloud.fill" , 1009 : "cloud.fill", 1030 : "cloud.fog.fill",1063 : "cloud.moon.rain", 1066 :"moon.snow",1069 : "cloud.sleet.fill", 1072 : "cloud.drizzle.fill"  , 1087 : "cloud.moon.bolt",1114 : "wind.snow", 1117 : "cloud.snow.fil", 1135 : "cloud.fog.fill", 1147 : "cloud.sleet.fill", 1150 : "cloud.drizzle.fill",1153 : "cloud.drizzle.fill", 1168 : "cloud.snow.fill", 1171 : "cloud.rain.fill", 1180 : "cloud.rain.fill", 1183 : "cloud.rain.fill",1186 : "cloud.moon.rain.fill", 1189 : "cloud.rain.fill", 1192 : "cloud.moon.rain.fill" , 1195 : "cloud.heavyrain.fill"  ,1198 : "cloud.sleet.fill",1201 : "cloud.sleet.fill", 1204 : "cloud.snow.fill", 1207 : "cloud.sleet.fill", 1210 : "moon.dust.fill", 1213 : "cloud.snow.fill",1216 : "moon.dust.fill", 1219 : "cloud.snow.fill", 1222 : "cloud.snow.fill", 1225 : "cloud.snow", 1237 : "cloud.sleet.fill",1240 :"cloud.drizzle.fill", 1243 : "cloud.heavyrain.fill" , 1246 : "cloud.rain.fill", 1249 : "cloud.drizzle.fill", 1252 : "cloud.heavyrain.fill",1255 : "cloud.snow.fill", 1258 : "cloud.snow.fill", 1261 :"cloud.sleet.fill", 1264 : "cloud.sleet.fill", 1273 : "cloud.hail.fill",1276 : "cloud.bolt.rain.fill", 1279 : "cloud.sleet.fill", 1282 : "cloud.snow.fill"]

    let dayIcon: [ Int : String ] = [1000 : "sun.max", 1003 : "cloud.sun.fill", 1006 : "cloud.fill", 1009 : "cloud.fill", 1030 : "cloud.fog",1063 : "cloud.sun.rain", 1066 : "sun.snow", 1069 : "cloud.sleet"      , 1072 : "cloud.drizzle", 1087 : "cloud.sun.bolt",1114 : "wind.snow", 1117 : "cloud.snow"       , 1135 : "cloud.fog", 1147 : "cloud.sleet", 1150 : "cloud.drizzle",1153 : "cloud.drizzle", 1168 : "cloud.snow", 1171 : "cloud.rain", 1180 : "cloud.rain.fill", 1183 : "cloud.rain.fill",1186 : "cloud.sun.rain", 1189 : "cloud.rain", 1192 : "cloud.sun.rain", 1195 : "cloud.heavyrain", 1198 : "cloud.sleet",1201 : "cloud.sleet", 1204 : "cloud.snow", 1207 : "cloud.sleet", 1210 : "sun.snow", 1213 : "cloud.snow",1216 : "sun.snow", 1219 : "cloud.snow", 1222 : "cloud.snow", 1225 : "cloud.snow", 1237 : "cloud.sleet",1240 : "cloud.drizzle", 1243 : "cloud.heavyrain"  , 1246 : "cloud.rain", 1249 : "cloud.drizzle", 1252 : "cloud.heavyrain",1255 : "cloud.snow", 1258 : "cloud.snow", 1261 : "cloud.sleet", 1264 : "cloud.sleet", 1273 : "cloud.hail",1276 : "cloud.bolt.rain", 1279 : "cloud.sleet", 1282 : "cloud.snow"]
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureView(weather : Weather , type : Int){
        self.viewBack.layer.cornerRadius = 8
        self.lblName.text = weather.location?.name ?? ""
        if type == 0{
            self.lblTemp.text = "\(weather.current?.tempC ?? 0)°"
        }
        else{
            self.lblTemp.text = "\(weather.current?.tempF ?? 0)°F"
        }
        if (weather.current?.isDay ?? 0 != 0){
            self.imgIcon.image = UIImage(systemName: "\(dayIcon[weather.current?.condition?.code ?? 0] ?? "")")
        }
        else{
            self.imgIcon.image = UIImage(systemName: "\(nightIcon[weather.current?.condition?.code ?? 0] ?? "")")
        }
    }

}
